from __future__ import annotations

import json
import os
import subprocess
import sys
import time
from pathlib import Path

import pandas as pd
import streamlit as st


ROOT = Path(__file__).resolve().parent
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

load_app_env(ROOT)

from paperbot.live_trader import get_account_snapshot
from paperbot.polymarket_account import fetch_account_activity, fetch_open_positions
from paperbot.reconciliation import sync_open_positions, sync_prediction_resolutions
from paperbot.storage import WeatherBotStorage
from paperbot.wallet_chain import fetch_public_wallet_snapshot
from paperbot.weather_dashboard_theme import configure_dashboard_theme
from paperbot.weather_dashboard_ui import (
    build_opportunities_frame,
    blocked_opportunities_frame,
    live_snapshot_curve_frame,
    positions_frame,
    public_closed_positions_frame,
    render_title,
    render_unified_dashboard,
    runs_frame,
)


def _resolve_path(value: str) -> Path:
    path = Path(value)
    if path.is_absolute():
        return path
    return ROOT / path


DB_PATH = _resolve_path(os.getenv("WEATHER_DB_PATH", "export/db/weather_bot.db"))
LATEST_JSON_PATH = _resolve_path(os.getenv("WEATHER_LATEST_JSON", "export/history/weather_model_latest.json"))
DEFAULT_REFRESH_SECONDS = int(os.getenv("WEATHER_DASHBOARD_REFRESH_SECONDS", "30"))
DEFAULT_MONITOR_SECONDS = int(os.getenv("WEATHER_MONITOR_INTERVAL_SECONDS", "60"))


configure_dashboard_theme()


def get_storage() -> WeatherBotStorage:
    return WeatherBotStorage(DB_PATH)


@st.cache_data(ttl=10)
def load_runs(limit: int = 50) -> list[dict]:
    return get_storage().list_runs(limit=limit)


@st.cache_data(ttl=10)
def load_run_details(run_id: str) -> dict:
    return get_storage().get_run_details(run_id)


@st.cache_data(ttl=10)
def load_positions(limit: int = 500) -> list[dict]:
    return get_storage().list_positions(limit=limit)


@st.cache_data(ttl=10)
def load_recent_opportunity_ranges(keys: tuple[tuple[str, str], ...]) -> dict:
    if not keys:
        return {}
    return get_storage().recent_opportunity_ranges(list(keys))


@st.cache_data(ttl=10)
def load_latest_dashboard_state() -> dict:
    runs = runs_frame(load_runs())
    positions = positions_frame(load_positions())
    live_positions = positions[positions["mode"] == "live"].copy() if not positions.empty else pd.DataFrame()
    live_open_positions = live_positions[live_positions["status"] == "open"].copy() if not live_positions.empty else pd.DataFrame()
    live_resolved_positions = live_positions[live_positions["status"] == "resolved"].copy() if not live_positions.empty else pd.DataFrame()
    latest_details = {"opportunities": [], "order_plans": []}
    if not runs.empty:
        latest_details = load_run_details(runs.iloc[0]["run_id"])
    recent_ranges = load_recent_opportunity_ranges(
        tuple((str(item.get("market_slug")), str(item.get("side"))) for item in latest_details.get("opportunities", []))
    )
    return {
        "runs_frame": runs,
        "live_positions": live_positions,
        "live_open_positions": live_open_positions,
        "live_resolved_positions": live_resolved_positions,
        "latest_details": latest_details,
        "opportunities": build_opportunities_frame(latest_details, live_open_positions, recent_ranges),
    }


@st.cache_data(ttl=10)
def load_latest_snapshot_json() -> dict:
    try:
        payload = json.loads(LATEST_JSON_PATH.read_text(encoding="utf-8"))
    except FileNotFoundError:
        return {}
    except Exception:
        return {}
    return payload if isinstance(payload, dict) else {}


@st.cache_data(ttl=30)
def load_wallet_snapshot() -> dict:
    return get_account_snapshot()


@st.cache_data(ttl=60)
def load_public_wallet_snapshot(clob_snapshot: dict) -> dict:
    return fetch_public_wallet_snapshot(clob_snapshot)


@st.cache_data(ttl=20)
def load_polymarket_positions(user: str | None) -> list[dict]:
    if not user:
        return []
    return fetch_open_positions(user)


@st.cache_data(ttl=20)
def load_polymarket_activity(user: str | None) -> list[dict]:
    if not user:
        return []
    return fetch_account_activity(user)


def run_scan_now(*, top: int, min_edge: float, min_consensus: float) -> tuple[bool, str]:
    command = [
        sys.executable,
        str(ROOT / "run_weather_models.py"),
        "--top",
        str(top),
        "--min-edge",
        str(min_edge),
        "--min-consensus",
        str(min_consensus),
    ]
    try:
        completed = subprocess.run(
            command,
            cwd=str(ROOT),
            capture_output=True,
            text=True,
            timeout=300,
            check=False,
        )
    except Exception as exc:
        return False, str(exc)
    message = (completed.stdout or completed.stderr or "").strip()
    if completed.returncode != 0:
        return False, message or f"scan retornou codigo {completed.returncode}"
    return True, message or "scan executado com sucesso"


def render_sidebar() -> dict[str, float | int]:
    st.sidebar.markdown(
        """
        <div class="sidebar-shell">
            <div class="sidebar-kicker">Weather Bot</div>
            <div class="sidebar-headline">Painel operacional</div>
            <div class="sidebar-sub">Resumo rapido, scanner, posicoes e PnL em um so lugar.</div>
        </div>
        """,
        unsafe_allow_html=True,
    )
    refresh_seconds = DEFAULT_REFRESH_SECONDS
    monitor_seconds = DEFAULT_MONITOR_SECONDS
    top = int(os.getenv("WEATHER_MONITOR_TOP", "5"))
    min_edge = float(os.getenv("WEATHER_MIN_EDGE", "10.0"))
    min_consensus = float(os.getenv("WEATHER_MIN_CONSENSUS", "0.35"))
    with st.sidebar.expander("Acoes", expanded=False):
        if st.button("Sincronizar resultados"):
            storage = get_storage()
            summary = sync_open_positions(storage)
            prediction_summary = sync_prediction_resolutions(storage)
            st.cache_data.clear()
            st.success(
                f"{summary['updated_positions']} posicoes e {prediction_summary['updated_predictions']} previsoes atualizadas"
            )
            st.rerun()
        if st.button("Atualizar painel"):
            st.cache_data.clear()
            st.rerun()
    st.sidebar.divider()
    if monitor_seconds > 0:
        st.sidebar.caption(f"Scanner live ativo: {int(monitor_seconds)}s")
    else:
        st.sidebar.caption("Scanner live desligado.")
    return {
        "refresh_seconds": int(refresh_seconds),
        "monitor_seconds": int(monitor_seconds),
        "top": int(top),
        "min_edge": float(min_edge),
        "min_consensus": float(min_consensus),
    }


def maybe_run_live_scan(*, monitor_seconds: int, top: int, min_edge: float, min_consensus: float) -> None:
    if monitor_seconds <= 0:
        return
    now = time.time()
    last_completed = float(st.session_state.get("dashboard_scan_last_completed_at", 0.0))
    running = bool(st.session_state.get("dashboard_scan_running", False))
    if running or (last_completed and now - last_completed < monitor_seconds):
        return
    st.session_state["dashboard_scan_running"] = True
    ok, message = run_scan_now(top=top, min_edge=min_edge, min_consensus=min_consensus)
    st.session_state["dashboard_scan_running"] = False
    st.session_state["dashboard_scan_last_completed_at"] = time.time()
    st.session_state["dashboard_scan_last_ok"] = ok
    st.session_state["dashboard_scan_last_message"] = message
    st.cache_data.clear()


def _load_dashboard_state() -> dict:
    state = load_latest_dashboard_state()
    latest_snapshot = load_latest_snapshot_json()
    wallet_snapshot = load_wallet_snapshot()
    public_wallet_snapshot = load_public_wallet_snapshot(wallet_snapshot)
    public_wallet_address = public_wallet_snapshot.get("address") if public_wallet_snapshot.get("ok") else None
    polymarket_positions = pd.DataFrame(load_polymarket_positions(public_wallet_address))
    polymarket_activity = load_polymarket_activity(public_wallet_address)
    effective_open_positions = polymarket_positions if not polymarket_positions.empty else state["live_open_positions"]
    effective_closed_positions = public_closed_positions_frame(polymarket_activity)
    if effective_closed_positions.empty:
        effective_closed_positions = state["live_resolved_positions"]
    latest_details = latest_snapshot if latest_snapshot else state.get("latest_details", {"opportunities": [], "order_plans": []})
    recent_ranges = load_recent_opportunity_ranges(
        tuple((str(item.get("market_slug")), str(item.get("side"))) for item in latest_details.get("opportunities", []))
    )
    opportunities = build_opportunities_frame(latest_details, effective_open_positions, recent_ranges)
    blocked_snapshot = {
        "blocked_opportunities": latest_snapshot.get("blocked_opportunities", []),
        "filter_rejections": latest_snapshot.get("filter_rejections", {}),
    }
    saldo_value = public_wallet_snapshot.get("liquid_cash_usd") if public_wallet_snapshot.get("ok") else None
    portfolio_rows = effective_open_positions if not effective_open_positions.empty else pd.DataFrame()
    portfolio_rows = portfolio_rows if portfolio_rows.empty else portfolio_rows.copy()
    from paperbot.dashboard_metrics import compute_open_position_totals

    portfolio_value, open_pnl_value = compute_open_position_totals(portfolio_rows)
    total_net_worth = (float(saldo_value) if saldo_value is not None else 0.0) + portfolio_value
    last_snapshot_at = float(st.session_state.get("dashboard_live_snapshot_last_written_at", 0.0))
    now = time.time()
    if now - last_snapshot_at >= 60:
        get_storage().record_live_account_snapshot(
            captured_at=pd.Timestamp.utcnow().isoformat(),
            saldo_usd=(float(saldo_value) if saldo_value is not None else None),
            portfolio_usd=portfolio_value,
            total_net_worth_usd=total_net_worth,
            total_open_pnl_usd=open_pnl_value,
            open_positions_count=0 if portfolio_rows.empty else len(portfolio_rows),
        )
        st.session_state["dashboard_live_snapshot_last_written_at"] = now
    return {
        "runs_frame": state["runs_frame"],
        "live_positions": state["live_positions"],
        "live_open_positions": state["live_open_positions"],
        "live_resolved_positions": state["live_resolved_positions"],
        "wallet_snapshot": wallet_snapshot,
        "public_wallet_snapshot": public_wallet_snapshot,
        "polymarket_positions": polymarket_positions,
        "polymarket_activity": polymarket_activity,
        "effective_open_positions": effective_open_positions,
        "effective_closed_positions": effective_closed_positions,
        "latest_details": latest_details,
        "opportunities": opportunities,
        "blocked_opportunities": blocked_opportunities_frame(blocked_snapshot),
        "filter_rejections": blocked_snapshot["filter_rejections"],
        "live_snapshot_curve": live_snapshot_curve_frame(get_storage().list_live_account_snapshots()),
    }


def main() -> None:
    controls = render_sidebar()
    refresh_interval = None if int(controls["refresh_seconds"]) <= 0 else int(controls["refresh_seconds"])
    scanner_interval = None if int(controls["monitor_seconds"]) <= 0 else int(controls["monitor_seconds"])
    st.session_state["dashboard_monitor_seconds"] = int(controls["monitor_seconds"])
    st.session_state["dashboard_refresh_seconds"] = int(controls["refresh_seconds"])
    st.session_state["dashboard_monitor_top"] = int(controls["top"])
    st.session_state["dashboard_monitor_min_edge"] = float(controls["min_edge"])
    st.session_state["dashboard_monitor_min_consensus"] = float(controls["min_consensus"])
    render_title()

    @st.fragment(run_every=1)
    def render_panel() -> None:
        state = _load_dashboard_state()
        render_unified_dashboard(
            state,
            run_scan_now_fn=run_scan_now,
            refresh_seconds=int(controls["refresh_seconds"]),
            monitor_seconds=int(controls["monitor_seconds"]),
        )

    @st.fragment(run_every=scanner_interval if scanner_interval is not None else refresh_interval)
    def run_background_scanner() -> None:
        maybe_run_live_scan(
            monitor_seconds=int(controls["monitor_seconds"]),
            top=int(controls["top"]),
            min_edge=float(controls["min_edge"]),
            min_consensus=float(controls["min_consensus"]),
        )

    run_background_scanner()
    render_panel()


if __name__ == "__main__":
    main()
from paperbot.env import load_app_env
