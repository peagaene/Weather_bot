param(
    [Parameter(Mandatory = $true)]
    [string]$EnvFile
)

$resolved = Resolve-Path $EnvFile -ErrorAction Stop
$lines = Get-Content $resolved
$allowed = @(
    "POLYMARKET_PRIVATE_KEY",
    "POLYMARKET_API_KEY",
    "POLYMARKET_API_SECRET",
    "POLYMARKET_API_PASSPHRASE",
    "POLYMARKET_FUNDER",
    "WEATHER_PUBLIC_WALLET_ADDRESS",
    "TOMORROW_API_KEY",
    "WEATHERAPI_KEY",
    "VISUAL_CROSSING_API_KEY",
    "OPENWEATHER_API_KEY",
    "POLYGON_RPC_URL",
    "POLYMARKET_CLOB_HOST",
    "POLYMARKET_CHAIN_ID",
    "POLYMARKET_SIGNATURE_TYPE"
)

$count = 0
foreach ($line in $lines) {
    $trimmed = $line.Trim()
    if (-not $trimmed -or $trimmed.StartsWith("#")) {
        continue
    }
    $parts = $trimmed.Split("=", 2)
    if ($parts.Count -ne 2) {
        continue
    }
    $name = $parts[0].Trim()
    $value = $parts[1]
    if ($allowed -contains $name) {
        [System.Environment]::SetEnvironmentVariable($name, $value, "User")
        $count += 1
    }
}

[System.Environment]::SetEnvironmentVariable("WEATHER_SKIP_DOTENV", "1", "User")
Write-Host "Segredos/imports atualizados no perfil do usuario: $count"
Write-Host "Abra um novo terminal antes de rodar o bot."
