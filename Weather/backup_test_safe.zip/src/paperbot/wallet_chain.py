from __future__ import annotations

import json
import os
import urllib.parse
import urllib.request
from typing import Any


POLYGON_RPC_URL = os.getenv("POLYGON_RPC_URL", "https://polygon-bor-rpc.publicnode.com")
BLOCKSCOUT_BASE_URL = os.getenv("POLYGON_BLOCKSCOUT_BASE_URL", "https://polygon.blockscout.com/api/v2")
STABLECOIN_SYMBOLS = {"USDC", "USDC.E", "USDCE", "USDT", "USDT.E", "DAI"}


def _request_json(url: str, *, method: str = "GET", payload: dict[str, Any] | None = None, timeout: float = 20.0) -> Any:
    headers = {
        "User-Agent": "weather-bot/1.0",
        "Accept": "application/json",
    }
    data = None
    if payload is not None:
        headers["Content-Type"] = "application/json"
        data = json.dumps(payload).encode("utf-8")
    request = urllib.request.Request(url=url, data=data, headers=headers, method=method)
    with urllib.request.urlopen(request, timeout=timeout) as response:
        return json.loads(response.read().decode("utf-8"))


def _safe_float(value: Any) -> float | None:
    try:
        if value is None:
            return None
        return float(value)
    except (TypeError, ValueError):
        return None


def _normalize_checksumish(address: str) -> str:
    return str(address or "").strip()


def _format_token_amount(raw_value: Any, decimals: int) -> float | None:
    try:
        if raw_value is None:
            return None
        return int(str(raw_value)) / float(10 ** decimals)
    except (TypeError, ValueError):
        return None


def resolve_public_wallet_address(clob_snapshot: dict[str, Any] | None = None) -> str | None:
    for env_key in ("WEATHER_PUBLIC_WALLET_ADDRESS", "POLYMARKET_FUNDER", "POLYMARKET_PUBLIC_ADDRESS"):
        candidate = _normalize_checksumish(os.getenv(env_key, ""))
        if candidate:
            return candidate
    if clob_snapshot and clob_snapshot.get("wallet_address"):
        return _normalize_checksumish(clob_snapshot["wallet_address"])
    return None


def fetch_native_balance(address: str) -> float | None:
    payload = {
        "jsonrpc": "2.0",
        "method": "eth_getBalance",
        "params": [address, "latest"],
        "id": 1,
    }
    data = _request_json(POLYGON_RPC_URL, method="POST", payload=payload)
    raw = data.get("result") if isinstance(data, dict) else None
    if not isinstance(raw, str):
        return None
    try:
        return int(raw, 16) / 1_000_000_000_000_000_000
    except ValueError:
        return None


def fetch_token_balances(address: str, *, limit: int = 50) -> list[dict[str, Any]]:
    url = f"{BLOCKSCOUT_BASE_URL}/addresses/{urllib.parse.quote(address, safe='')}/token-balances"
    data = _request_json(url)
    if not isinstance(data, list):
        return []
    output: list[dict[str, Any]] = []
    for item in data:
        token = item.get("token") or {}
        decimals = int(str(token.get("decimals") or "0"))
        balance = _format_token_amount(item.get("value"), decimals)
        symbol = str(token.get("symbol") or token.get("name") or "").strip() or "TOKEN"
        price = _safe_float(token.get("exchange_rate"))
        usd_value = (balance * price) if balance is not None and price is not None else None
        output.append(
            {
                "symbol": symbol,
                "name": str(token.get("name") or symbol),
                "balance": balance,
                "usd_value": usd_value,
                "token_address": token.get("address_hash"),
                "icon_url": token.get("icon_url"),
            }
        )
    output.sort(key=lambda row: (row["usd_value"] is not None, row["usd_value"] or 0.0, row["balance"] or 0.0), reverse=True)
    return output[:limit]


def fetch_recent_transfers(address: str, *, limit: int = 10) -> list[dict[str, Any]]:
    url = f"{BLOCKSCOUT_BASE_URL}/addresses/{urllib.parse.quote(address, safe='')}/token-transfers"
    data = _request_json(url)
    items = data.get("items", []) if isinstance(data, dict) else []
    output: list[dict[str, Any]] = []
    address_norm = address.lower()
    for item in items[:limit]:
        token = item.get("token") or {}
        total = item.get("total") or {}
        decimals = int(str(total.get("decimals") or token.get("decimals") or "0"))
        amount = _format_token_amount(total.get("value"), decimals)
        from_hash = str(((item.get("from") or {}).get("hash")) or "")
        to_hash = str(((item.get("to") or {}).get("hash")) or "")
        direction = "IN" if to_hash.lower() == address_norm else "OUT"
        output.append(
            {
                "timestamp": item.get("timestamp"),
                "direction": direction,
                "symbol": str(token.get("symbol") or token.get("name") or "TOKEN"),
                "amount": amount,
                "method": item.get("method"),
                "transaction_hash": item.get("transaction_hash"),
                "counterparty": from_hash if direction == "IN" else to_hash,
            }
        )
    return output


def fetch_public_wallet_snapshot(clob_snapshot: dict[str, Any] | None = None) -> dict[str, Any]:
    address = resolve_public_wallet_address(clob_snapshot)
    if not address:
        return {"ok": False, "error": "WEATHER_PUBLIC_WALLET_ADDRESS not configured"}

    try:
        native_balance = fetch_native_balance(address)
        token_balances = fetch_token_balances(address)
        recent_transfers = fetch_recent_transfers(address)
        total_token_usd = sum(item["usd_value"] or 0.0 for item in token_balances)
        liquid_cash_usd = sum(
            item["usd_value"] or 0.0
            for item in token_balances
            if str(item.get("symbol") or "").upper() in STABLECOIN_SYMBOLS
        )
        return {
            "ok": True,
            "address": address,
            "native_symbol": "POL",
            "native_balance": native_balance,
            "token_balances": token_balances,
            "recent_transfers": recent_transfers,
            "tracked_token_usd": total_token_usd,
            "liquid_cash_usd": liquid_cash_usd,
            "explorer_url": f"https://polygon.blockscout.com/address/{address}",
        }
    except Exception as exc:
        return {"ok": False, "address": address, "error": str(exc)}
